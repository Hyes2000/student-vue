<template>
    <div>
      <h1>404,码没了</h1>
    </div>
</template>

<script>
  export default {
    name: 'NotFound'
  }
</script>

<style scoped>

</style>
