<template>
    <div>
      <h1>课程信息</h1>
    </div>
</template>

<script>
  export default {
    props:['name'],
    name: 'Curriculum'
  }
</script>

<style scoped>

</style>
