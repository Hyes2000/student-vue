<template>

  <div>
    <h1>用户列表</h1>
   <h1> {{$route.params.name}}</h1>
  </div>
</template>

<script>
  export default {

    name: 'List'
  }
</script>

<style scoped>

</style>
